module com.uas.FlowGerStore {
    requires transitive javafx.controls;
    requires transitive java.sql;

    exports com.uas.FlowGerStore;
}
