package com.uas.FlowGerStore;

import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.VBox;

public class ViewHome {
    private VBox pane;
    public ViewHome(){
        pane = new VBox();
            try{
            pane.setBackground(new Background(new BackgroundImage(new Image(getClass().getResourceAsStream("bg.jpg")), null, null, null, new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, true, true, false, true))));
        }catch(Exception er){System.out.println(er);}
    }
    public VBox getViews(){return pane;}
}
