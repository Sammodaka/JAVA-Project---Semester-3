package com.uas.FlowGerStore;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.ResultSet;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.util.Callback;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
public class ViewManageType extends Views {
    private ModelFlowerType selectedItem = null;

    private TableView<ModelFlowerType> viewList = new TableView<ModelFlowerType>();
    private TableColumn<ModelFlowerType, Integer> typeIDColumn = new TableColumn<ModelFlowerType, Integer>("Type ID");
    private TableColumn<ModelFlowerType, String> typeNameColumn = new TableColumn<ModelFlowerType, String>("Type Name");

    private Label idLabel = new Label("Type ID");
    private Label nameLabel = new Label("Type Name");

    private TextField idField = new TextField();
    private TextField nameField = new TextField();

    private Button addButton = new Button("Add Type");
    private Button updateButton = new Button("Update Type");
    private Button deleteButton = new Button("Delete Type");

    private GridPane controlPane = new GridPane();
    private HBox pane;

    public ViewManageType(){
        typeIDColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlowerType, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelFlowerType, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().typeID)).asObject();
            }
        });
        typeNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlowerType, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelFlowerType, String> p) {
                return new SimpleStringProperty(p.getValue().typeName);
            }
        });

        viewList.getColumns().addAll(typeIDColumn,typeNameColumn);

        controlPane.add(idLabel, 0, 0);
        controlPane.add(idField, 1, 0);
        controlPane.add(nameLabel, 0, 1);
        controlPane.add(nameField, 1, 1);
        controlPane.add(addButton, 0, 2,2,1);
        controlPane.add(updateButton, 0, 3,2,1);
        controlPane.add(deleteButton, 0, 4,2,1);
        controlPane.setHgap(5);
        controlPane.setVgap(5);
        controlPane.setAlignment(Pos.CENTER);

        pane = new HBox(viewList,controlPane);
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(110);
        pane.setPadding(new Insets(90,0,90,0));
        pane.setStyle("-fx-background-color:rgba(20, 90, 200, 0.7)");
        pane.setPrefHeight(480);

        viewList.addEventHandler(MouseEvent.MOUSE_CLICKED, listEH);
        addButton.addEventHandler(MouseEvent.MOUSE_CLICKED, addEH);
        updateButton.addEventHandler(MouseEvent.MOUSE_CLICKED, updateEH);
        deleteButton.addEventHandler(MouseEvent.MOUSE_CLICKED, deleteEH);

        addButton.setPrefWidth(300);
        updateButton.setPrefWidth(300);
        deleteButton.setPrefWidth(300);

        idField.setDisable(true);

        App.setWidth(700.0);

        updateViews();
    }

    public void updateViews(){
        ResultSet rs;
        try{
            final ObservableList<ModelFlowerType> items = FXCollections.observableArrayList();
            rs = new ModelFlowerType().search("");
            while(rs.next()) items.add(new ModelFlowerType(rs.getInt("typeID")));
            viewList.setItems(items);
        }catch(Exception e){System.out.println(e);}
    }
    public void clearFormViews(){
        idField.setText("");
        nameField.setText("");
    }
    public Parent getViews(){
        VBox views = new ViewHome().getViews();
        views.getChildren().add(pane);
        return views;
    }
    public boolean validateFields(){
        if(!(nameField.getText().length() >= 10 && nameField.getText().length() <= 20)){
            alert("Flower neme must be 10-20",ERROR);
            return false;
        }else if(!isNameUnique(nameField.getText())){
            alert("Type already exists in database!",ERROR);
            return false;
        }
        return true;
    }

    public boolean isNameUnique(String str){
        for(ModelFlowerType type : viewList.getItems()){
            if (str.equals(type.typeName)) return false;
        }
        return true;
    }


    EventHandler<MouseEvent> listEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) { 
            selectedItem =  viewList.getSelectionModel().getSelectedItem();
            idField.setText(String.valueOf(selectedItem.typeID));
            nameField.setText(selectedItem.typeName);
        }
    };

    EventHandler<MouseEvent> addEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            boolean validate = validateFields();
            if (validate) {
                try{
                    var modelType = new ModelFlowerType();
                    String data ="("+modelType.getNewID()+",'"+nameField.getText()+"')";
                    modelType.create(data);
                    selectedItem = null;
                    alert("Successfully Add Type!",INFORMATION);
                    updateViews();
                    clearFormViews();
                }catch(Exception err){
                    System.out.println(err);
                    alert("Something went wrong!",ERROR);
                }
            }
        }
    };

    EventHandler<MouseEvent> updateEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            if(selectedItem == null){
                alert("Please select a type!",ERROR);
            }else {
                boolean validate = validateFields();
                if (validate) {
                    try{
                        selectedItem.write("typeName = '" + nameField.getText()+"'","typeID = " + selectedItem.typeID);
                        selectedItem = null;
                        alert("Successfully Update Type!",INFORMATION);
                        updateViews();
                        clearFormViews();
                    }catch(Exception err){
                        System.out.println(err);
                        alert("Something went wrong!",ERROR);
                    }
                }
            }
        }
    };

    EventHandler<MouseEvent> deleteEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            if(selectedItem == null){
                alert("Please select a flower!",ERROR);
            }else {
                try{
                    selectedItem.unlink("typeID = "+selectedItem.typeID);
                    selectedItem = null;
                    alert("Successfully Delete Type!",INFORMATION);
                    updateViews();
                    clearFormViews();
                }catch(Exception err){
                    System.out.println(err);
                    alert("Something went wrong!",ERROR);
                }
            }
        }
    };
}
