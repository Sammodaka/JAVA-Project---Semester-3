package com.uas.FlowGerStore;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
// import javafx.scene.layout.VBox;
import javafx.scene.layout.VBox;

public class LayoutMenu {
    private MenuBar menuBar = new MenuBar();
    private Menu userMenu;
    private Menu appsMenu;
    private MenuItem manageFlowerMenuItem = new MenuItem("Manage Flower");
    private MenuItem manageTypeMenuItem = new MenuItem("Manage Type");
    private MenuItem transactionMenuItem = new MenuItem("Transaction");
    private MenuItem logoutMenuItem = new MenuItem("Log Out");
    private MenuItem orderFlowerMenuItem = new MenuItem("Order Flower");

    public LayoutMenu(){
        menuBar = new MenuBar();
        ModelUser user = App.getUser();
        String userRole = user.userRole;

        // give label to the menu
        userMenu = new Menu(user.userName);
        appsMenu = new Menu(userRole.equals("Staff")?"Manage":"Transaction");

        // add menu item to the menu and set the action
        if(user != null) {

            userMenu.getItems().addAll(logoutMenuItem);
            if(user.userRole.equals("Staff")){
                appsMenu.getItems().addAll(manageFlowerMenuItem,manageTypeMenuItem); 
            }else{
                appsMenu.getItems().addAll(orderFlowerMenuItem,transactionMenuItem);
            }

            manageFlowerMenuItem.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent event) {
                    try{
                       App.setRoot(new VBox(new LayoutMenu().getViews(),new ViewManageFlower().getViews()));
                    }catch(Exception err){
                        System.out.println(err);
                    }
                }
            });
            manageTypeMenuItem.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent event) {
                    try{
                       App.setRoot(new VBox(new LayoutMenu().getViews(),new ViewManageType().getViews()));
                    }catch(Exception err){
                        System.out.println(err);
                    }
                }
            });
            orderFlowerMenuItem.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent event) {
                    try{
                       App.setRoot(new VBox(new LayoutMenu().getViews(),new ViewOrderFlower().getViews()));
                    }catch(Exception err){
                        System.out.println(err);
                    }
                }
            });
            transactionMenuItem.setOnAction(new EventHandler<ActionEvent>() {
                public void handle(ActionEvent event) {
                    try{
                       App.setRoot(new VBox(new LayoutMenu().getViews(),new ViewTransactionHistory().getViews()));
                    }catch(Exception err){
                        System.out.println(err);
                    }
                }
            });
            menuBar.getMenus().addAll(userMenu,appsMenu);

        }
    }
    public MenuBar getViews(){return menuBar;}
}
