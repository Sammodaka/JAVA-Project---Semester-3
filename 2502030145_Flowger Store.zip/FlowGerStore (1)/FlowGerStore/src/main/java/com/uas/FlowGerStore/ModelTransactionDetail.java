package com.uas.FlowGerStore;

import java.sql.ResultSet;

public class ModelTransactionDetail extends Model{
    public String tableName = "transaction_detail";

    public int transactionID;
    public ModelFlower flowerID;
    public int quantity;

    public ModelTransactionDetail(){}
    public ModelTransactionDetail(int tid,int fid){
        ResultSet rs;
        try{
            rs = this.search("transactionID = " + tid + " and flowerID = " + fid);
            if(rs.next()){
                transactionID = rs.getInt("transactionID");
                flowerID = new ModelFlower(rs.getInt("flowerID"));
                quantity = rs.getInt("quantity");
            }
        }catch(Exception e){System.out.println(e);}
    }
    public ModelTransactionDetail(int transactionID, ModelFlower flowerID, int quantity){
        this.transactionID = transactionID;
        this.flowerID = flowerID;
        this.quantity = quantity;
    }
}
