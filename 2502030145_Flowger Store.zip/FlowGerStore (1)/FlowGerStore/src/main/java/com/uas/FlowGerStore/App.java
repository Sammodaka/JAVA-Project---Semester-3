package com.uas.FlowGerStore;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


//FINAL PRAKTIKUM PROJECT "FloWGer Store"

//2502030145 - Sammodaka Wijaya
//2501982115 - Gregory Edmund Wiryadi
//2501963873 - Tommy
//2540110672 - Matthew Sebastian Pandy

/**
 * JavaFX App
 */
public class App extends Application {
    private static Scene scene = new Scene(new VBox(), 640, 480);
    private static ModelUser user = null;
    // private static ModelUser user = new ModelUser(1);

    @Override
    public void start(Stage stage) {
        stage.setScene(scene);
        stage.setResizable(false);
        scene.setRoot(new ViewLogin().getViews());
        stage.setTitle("FloWGer Store");
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
    public static void setRoot(Parent root){
        scene.setRoot(root);
    }
    static void setUser(ModelUser u){
        user = u;
    }
    static ModelUser getUser(){
        return user;
    }
    static void setWidth(Double width){
        scene.getWindow().setWidth(width);
    }
    static void setHeight(Double height){
        scene.getWindow().setHeight(height);
    }
}