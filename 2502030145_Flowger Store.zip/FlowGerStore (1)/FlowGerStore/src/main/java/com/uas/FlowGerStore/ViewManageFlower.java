package com.uas.FlowGerStore;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.ResultSet;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.util.Callback;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
public class ViewManageFlower extends Views {
    private ModelFlower selectedItem = null;

    private TableView<ModelFlower> viewList = new TableView<ModelFlower>();
    private TableColumn<ModelFlower, Integer> flowerIDColumn = new TableColumn<ModelFlower, Integer>("Flower ID");
    private TableColumn<ModelFlower, String> flowerNameColumn = new TableColumn<ModelFlower, String>("Flower Name"); 
    private TableColumn<ModelFlower, String> flowerTypeColumn = new TableColumn<ModelFlower, String>("Flower Type");
    private TableColumn<ModelFlower, Integer> flowerPriceColumn = new TableColumn<ModelFlower, Integer>("Flower Price");
    private TableColumn<ModelFlower, Integer> flowerStockColumn = new TableColumn<ModelFlower, Integer>("Flower Stock");

    private Label idLabel = new Label("Flower ID");
    private Label nameLabel = new Label("Flower Name");
    private Label priceLabel = new Label("Flower Price");
    private Label typeLabel = new Label("Flower Type");
    private Label stockLabel = new Label("Flower Stock");

    private TextField idField = new TextField();
    private TextField nameField = new TextField();
    private TextField priceField = new TextField();
    private ComboBox<ModelFlowerType> typeField = new ComboBox<ModelFlowerType>();
    private Spinner<Integer> stockField  =  new Spinner<Integer>(0,100,0,1);

    private Button addButton = new Button("Add Flower");
    private Button updateButton = new Button("Update Flower");
    private Button deleteButton = new Button("Delete Flower");

    private VBox buttonPane, pane;
    private GridPane formPane = new GridPane();
    private HBox formView;


    public ViewManageFlower(){
        flowerIDColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelFlower, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerID)).asObject();
            }
        });
        flowerNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelFlower, String> p) {
                return new SimpleStringProperty(p.getValue().flowerName);
            }
        });
        flowerTypeColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelFlower, String> p) {
                return new SimpleStringProperty(p.getValue().typeID.typeName);
            }
        });
        flowerPriceColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelFlower, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerPrice)).asObject();
            }
        });
        flowerStockColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelFlower, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerStock)).asObject();
            }
        });
        viewList.getColumns().addAll(flowerIDColumn,flowerNameColumn,flowerTypeColumn,flowerPriceColumn,flowerStockColumn);


        idField.setPromptText("Flower ID");
        nameField.setPromptText("Flower Name");
        priceField.setPromptText("Flower Price");

        typeField.setPrefWidth(180);
        stockField.setPrefWidth(180);

        idField.setDisable(true);

        formPane.add(idLabel,0,0);
        formPane.add(idField,1,0);
        formPane.add(nameLabel,0,1);
        formPane.add(nameField,1,1);
        formPane.add(priceLabel,0,2);
        formPane.add(priceField,1,2);
        formPane.add(typeLabel,0,3);
        formPane.add(typeField,1,3);
        formPane.add(stockLabel,0,4);
        formPane.add(stockField,1,4);
        formPane.setVgap(10);
        formPane.setHgap(10);

        addButton.setPrefWidth(300);
        updateButton.setPrefWidth(300);
        deleteButton.setPrefWidth(300);

        buttonPane = new VBox(addButton,updateButton,deleteButton);
        buttonPane.setAlignment(Pos.CENTER_RIGHT);

        formView = new HBox(formPane, buttonPane);
        formView.setSpacing(60);

        pane = new VBox(viewList,formView);
        pane.setSpacing(10);
        pane.setPadding(new Insets(20));
        pane.setStyle("-fx-background-color:rgba(20, 90, 200, 0.7)");

        viewList.addEventHandler(MouseEvent.MOUSE_CLICKED, listEH);
        addButton.addEventHandler(MouseEvent.MOUSE_CLICKED, addEH);
        updateButton.addEventHandler(MouseEvent.MOUSE_CLICKED, updateEH);
        deleteButton.addEventHandler(MouseEvent.MOUSE_CLICKED, deleteEH);

        App.setWidth(700.0);

        updateViews();
    }
    public void updateViews(){
        ResultSet rs;
        try{
            final ObservableList<ModelFlower> items = FXCollections.observableArrayList();
            rs = new ModelFlower().search("");
            while(rs.next()) items.add(new ModelFlower(rs.getInt("flowerID")));
            viewList.setItems(items);

            rs = new ModelFlowerType().search("");
            while(rs.next()) typeField.getItems().add(new ModelFlowerType(rs.getInt("typeID")));
        }catch(Exception e){System.out.println(e);}
    }
    public void clearFormViews(){
        idField.setText("");
        nameField.setText("");
        priceField.setText("");
        stockField.getValueFactory().setValue(0);    
        typeField.setValue(null);    
    }
    public Parent getViews(){
        VBox views = new ViewHome().getViews();
        views.getChildren().add(pane);
        return views;
    }
    EventHandler<MouseEvent> listEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) { 
            selectedItem =  viewList.getSelectionModel().getSelectedItem();
            idField.setText(String.valueOf(selectedItem.flowerID));
            nameField.setText(selectedItem.flowerName);
            priceField.setText(""+selectedItem.flowerPrice);
            typeField.setValue(selectedItem.typeID);
            stockField.getValueFactory().setValue(selectedItem.flowerStock);

        }
    };

    EventHandler<MouseEvent> addEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            boolean validate = validateFields();
            if (validate) {
                try{
                    var modelFlower = new ModelFlower();
                    String data ="("+modelFlower.getNewID()+","+typeField.getValue().typeID+",'"+nameField.getText()+"',"+priceField.getText()+","+stockField.getValue()+")";
                    modelFlower.create(data);
                    selectedItem = null;
                    alert("Successfully Add Flower!",INFORMATION);
                    updateViews();
                    clearFormViews();
                }catch(Exception err){
                    System.out.println(err);
                    alert("Something went wrong!",ERROR);
                }
            }
        }
    };

    EventHandler<MouseEvent> updateEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            if(selectedItem == null){
                alert("Please select a flower!",ERROR);
            }else {
                boolean validate = validateFields();
                if (validate) {
                    try{
                        var modelFlower = new ModelFlower();
                        String data ="typeID = "+typeField.getValue().typeID+", flowerName = '"+nameField.getText()+"', flowerPrice = "+priceField.getText()+", flowerStock = "+stockField.getValue();
                        modelFlower.write(data,"flowerID = "+selectedItem.flowerID);
                        selectedItem = null;
                        alert("Successfully Update Flower!",INFORMATION);
                        updateViews();
                        clearFormViews();
                    }catch(Exception err){
                        System.out.println(err);
                        alert("Something went wrong!",ERROR);
                    }
                }
            }
        }
    };

    EventHandler<MouseEvent> deleteEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            if(selectedItem == null){
                alert("Please select a flower!",ERROR);
            }else {
                try{
                    selectedItem.unlink("flowerID = "+selectedItem.flowerID);
                    selectedItem = null;
                    alert("Successfully Delete Flower!",INFORMATION);
                    updateViews();
                    clearFormViews();
                }catch(Exception err){
                    System.out.println(err);
                    alert("Something went wrong!",ERROR);
                }
            }
        }
    };

    public boolean validateFields(){
        if(nameField.getText().length() < 15){
            alert("Flower neme elngth minmal 15 characters!",ERROR);
            return false;
        }else if(!isNumber(priceField.getText())){
            alert("Price must be numeric!",ERROR);
            return false;
        }else if(Integer.valueOf(priceField.getText())<=0){
            alert("Price must more than 0!",ERROR);
            return false;
        }else if(typeField.getValue() == null){
            alert("Type must be choosed!",ERROR);
            return false;
        }else if(stockField.getValue() <= 0){
            alert("Stock must more than 0!",ERROR);
            return false;
        }
        return true;
    }

    public boolean isNumber(String str){
        try{
            Integer.valueOf(str);
            return true;
        }catch(Exception e){return false;}
    }
}
