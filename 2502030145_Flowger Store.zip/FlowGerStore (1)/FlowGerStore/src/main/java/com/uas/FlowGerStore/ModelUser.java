package com.uas.FlowGerStore;

import java.sql.ResultSet;

public class ModelUser extends Model{
    public String tableName = "user";

    public int userID;
    public String userName;
    public String userEmail;
    public String userGender;
    public String userRole;

    public ModelUser(){}
    public ModelUser(int id){
        ResultSet res;
        try{
            res = this.search("userID = "+id);
            res.next();
            userID = res.getInt("userID");
            userName = res.getString("userName");
            userEmail = res.getString("userEmail");
            userGender = res.getString("userGender");
            userRole = res.getString("userRole");
        }catch(Exception err){
            System.out.println(err);
        }
    }
    public int getNewID() throws Exception{
        ResultSet rs = this.search("");
        int id = 0;
        while(rs.next()){
            int cid = rs.getInt("userID");
            id = cid > id?cid:id;
        }
        return id + 1;
    }
    
}
