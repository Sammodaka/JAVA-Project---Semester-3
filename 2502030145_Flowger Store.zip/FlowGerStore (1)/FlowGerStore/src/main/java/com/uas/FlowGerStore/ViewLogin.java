package com.uas.FlowGerStore;


import java.sql.ResultSet;

import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class ViewLogin extends Views {
    private Label title = new Label("Login Form");
    private Label emailLabel = new Label("Email");
    private Label passwordLabel = new Label("Password");
    private TextField emailField = new TextField();
    private PasswordField passwordField = new PasswordField();

    private Button loginButton = new Button("Login");
    private Button registerButton = new Button("Register");

    private VBox pane;
    private HBox buttonPane;
    private GridPane formPane;

    public ViewLogin() {
        formPane = new GridPane();
        formPane.add(emailLabel, 0, 0);
        formPane.add(emailField, 1, 0);
        formPane.add(passwordLabel, 0, 1);
        formPane.add(passwordField, 1, 1);
        formPane.setHgap(10);
        formPane.setVgap(10);
        formPane.setAlignment(Pos.CENTER);

        buttonPane = new HBox(loginButton,registerButton);
        buttonPane.setSpacing(10);
        buttonPane.setAlignment(Pos.CENTER);

        pane = new VBox(title,formPane,buttonPane);
        pane.setAlignment(Pos.CENTER);
        pane.setSpacing(20);
        pane.setPadding(new Insets(10));

        loginButton.addEventHandler(MouseEvent.MOUSE_CLICKED, loginEH);
        registerButton.addEventHandler(MouseEvent.MOUSE_CLICKED, registerEH);
    }

    public Parent getViews(){return pane;}

    EventHandler<MouseEvent> loginEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            try{
                ResultSet rs = new ModelUser().search("userEmail = '"+emailField.getText()+"' and userPassword = '"+passwordField.getText()+"'");
                if(rs.next()){
                    App.setUser(new ModelUser(rs.getInt("userID")));
                    alert("Success!",INFORMATION);
                    VBox home = new ViewHome().getViews();
                    home.getChildren().add(new LayoutMenu().getViews());
                    App.setRoot(home);
                }else{
                    alert("User Does Not Exist!",ERROR);
                }
            }catch(Exception err){
                System.out.println(err);
                alert("Something went wrong!",ERROR);
            }
        }
    };

    EventHandler<MouseEvent> registerEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            App.setRoot(new ViewRegister().getViews());
        }
    };

}
