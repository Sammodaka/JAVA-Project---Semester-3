package com.uas.FlowGerStore;
import java.util.regex.Pattern;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.VBox;

public class ViewRegister extends Views {
    private Label title = new Label("Register Form");
    private Label nameLabel = new Label("Name");
    private Label emailLabel = new Label("Email");
    private Label passwordLabel = new Label("Password");
    private Label genderLabel = new Label("Gender");
    private Label roleLabel = new Label("Role");

    private TextField nameField = new TextField();
    private TextField emailField = new TextField();
    private PasswordField passwordField = new PasswordField();
    private ToggleGroup genderToggleGroup = new ToggleGroup();
    private VBox genderField;
    private RadioButton maleRadioButton = new RadioButton("Male");
    private RadioButton femaleRadioButton = new RadioButton("Female");
    private String[] roles = {"User","Staff"};
    private ComboBox<String> roleField = new ComboBox<String>(FXCollections.observableArrayList(roles));

    private Button registerButton = new Button("Register");
    private Button backButton = new Button("Back");

    private VBox pane;
    private HBox buttonPane;
    private GridPane formPane;

    public ViewRegister(){
        maleRadioButton.setToggleGroup(genderToggleGroup);
        femaleRadioButton.setToggleGroup(genderToggleGroup);
        genderField = new VBox(maleRadioButton,femaleRadioButton);
        genderField.setSpacing(10);


        formPane = new GridPane();
        formPane.add(nameLabel,0,0);
        formPane.add(nameField,1,0);
        formPane.add(emailLabel,0,1);
        formPane.add(emailField,1,1);
        formPane.add(passwordLabel,0,2);
        formPane.add(passwordField,1,2);
        formPane.add(genderLabel,0,3);
        formPane.add(genderField,1,3);
        formPane.add(roleLabel,0,4);
        formPane.add(roleField,1,4);
        formPane.setHgap(10);
        formPane.setVgap(10);
        formPane.setAlignment(Pos.CENTER);

        buttonPane = new HBox(registerButton,backButton);
        buttonPane.setAlignment(Pos.CENTER);
        buttonPane.setSpacing(10);

        pane = new VBox(title,formPane,buttonPane);
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10));
        pane.setSpacing(60);

        registerButton.addEventHandler(MouseEvent.MOUSE_CLICKED, registerEH);
        backButton.addEventHandler(MouseEvent.MOUSE_CLICKED, backEH);
    }
    public Parent getViews(){return pane;}

    EventHandler<MouseEvent> backEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            App.setRoot(new ViewLogin().getViews());
        }
    };

    EventHandler<MouseEvent> registerEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            if(validate()){
                try{
                    var model = new ModelUser();
                    RadioButton gender = (RadioButton) genderToggleGroup.getSelectedToggle();
                    model.create("("+model.getNewID()+",'"+nameField.getText()+"','"+emailField.getText()+"','"+passwordField.getText()+"','"+gender.getText()+"','"+roleField.getValue()+"')");
                    alert("Register Succeed",INFORMATION);
                    App.setRoot(new ViewLogin().getViews());
                }catch(Exception err){
                    System.out.println(err);
                    alert("Something went wrong!",ERROR);
                }
            }
        }
    };
    private boolean validate(){
        RadioButton gender = (RadioButton) genderToggleGroup.getSelectedToggle();

        Pattern pattern = Pattern.compile("^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
        + "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$", Pattern.CASE_INSENSITIVE);
        if(!(nameField.getText().length() > 5 && nameField.getText().length() < 30)){
            alert("Name length must be 5 - 30!",ERROR);
            return false;
        }else if(!(pattern.matcher(emailField.getText()).find())){
            alert("Invalid email format!",ERROR);
            return false;
        }else if(!(passwordField.getText().length() > 5 && passwordField.getText().length() < 25)){
            alert("Password must be between 5 - 25 characters",ERROR);
            return false;
        }else if(gender.getText().equals("")){
            alert("Gender must be choosed",ERROR);
            return false;
        }else if(roleField.getValue().equals("")){
            alert("Role must be choosed",ERROR);
            return false;
        }
        return true;
    }

}
