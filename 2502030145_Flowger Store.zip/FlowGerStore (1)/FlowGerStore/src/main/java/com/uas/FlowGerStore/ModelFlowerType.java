package com.uas.FlowGerStore;

import java.sql.ResultSet;

public class ModelFlowerType extends Model{
    public String tableName = "flower_type";

    public int typeID;
    public String typeName;

    public ModelFlowerType(){}
    public ModelFlowerType(int id){
        ResultSet res;
        try{
            res = this.search("typeID = "+id);
            if(res.next()){

                typeID = res.getInt("typeID");
                typeName = res.getString("typeName");
            }
        }catch(Exception e){System.out.println(e);}
    }

    public int getNewID() throws Exception{
        ResultSet rs = this.search("");
        int id = 0;
        while(rs.next()){
            int cid = rs.getInt("typeID");
            id = cid > id?cid:id;
        }
        return id + 1;
    }

    public String toString(){return typeName;}
    
}
