package com.uas.FlowGerStore;
import javafx.scene.Parent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.sql.ResultSet;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.util.Callback;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
public class ViewTransactionHistory extends Views {
    private ModelTransaction selectedItem = null;

    private TableView<ModelTransaction> viewList = new TableView<ModelTransaction>();
    private TableColumn<ModelTransaction, Integer> transactionIDColumn = new TableColumn<ModelTransaction, Integer>("Transaction ID");
    private TableColumn<ModelTransaction, Integer> transactionUserIDColumn = new TableColumn<ModelTransaction, Integer>("User ID");
    private TableColumn<ModelTransaction, String> transactionDateColumn = new TableColumn<ModelTransaction, String>("Transaction Date");
    private TableColumn<ModelTransaction, Integer> transactionTotalPriceColumn = new TableColumn<ModelTransaction, Integer>("Total Price");

    private TableView<ModelTransactionDetail> detailList = new TableView<ModelTransactionDetail>();
    private TableColumn<ModelTransactionDetail, Integer> detailFlowerIDColumn = new TableColumn<ModelTransactionDetail, Integer>("Flower ID");
    private TableColumn<ModelTransactionDetail, String> detailFlowerNameColumn = new TableColumn<ModelTransactionDetail, String>("Flower Name");
    private TableColumn<ModelTransactionDetail, Integer> detailFlowerPriceColumn = new TableColumn<ModelTransactionDetail, Integer>("Flower Price");
    private TableColumn<ModelTransactionDetail, String> detailFlowerTypeColumn = new TableColumn<ModelTransactionDetail, String>("Flower Type");
    private TableColumn<ModelTransactionDetail, Integer> detailQuantityColumn = new TableColumn<ModelTransactionDetail, Integer>("Quantity");

    private VBox pane;

    public ViewTransactionHistory(){
        transactionIDColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransaction, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelTransaction, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().transactionID)).asObject();
            }
        });
        transactionUserIDColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransaction, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelTransaction, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().userID.userID)).asObject();
            }
        });
        transactionDateColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransaction, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelTransaction, String> p) {
                return new SimpleStringProperty(p.getValue().transactionDate);
            }
        });
        transactionTotalPriceColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransaction, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelTransaction, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().getTotalPrice())).asObject();
            }
        });
        viewList.getColumns().addAll(transactionIDColumn,transactionUserIDColumn,transactionDateColumn,transactionTotalPriceColumn);
        
        detailFlowerIDColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransactionDetail, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelTransactionDetail, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerID.flowerID)).asObject();
            }
        });
        detailFlowerNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransactionDetail, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelTransactionDetail, String> p) {
                return new SimpleStringProperty(p.getValue().flowerID.flowerName);
            }
        });
        detailFlowerPriceColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransactionDetail, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelTransactionDetail, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerID.flowerPrice)).asObject();
            }
        });
        detailFlowerTypeColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransactionDetail, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelTransactionDetail, String> p) {
                return new SimpleStringProperty(p.getValue().flowerID.typeID.typeName);
            }
        });
        detailQuantityColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelTransactionDetail, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelTransactionDetail, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().quantity)).asObject();
            }
        });
        detailList.getColumns().addAll(detailFlowerIDColumn,detailFlowerNameColumn,detailFlowerPriceColumn,detailFlowerTypeColumn,detailQuantityColumn);

        pane = new VBox(viewList,detailList);
        pane.setSpacing(10);
        pane.setStyle("-fx-background-color:rgba(20, 90, 200, 0.7)");
        pane.setPadding(new Insets(20, 20, 0, 20));

        App.setWidth(650.0);

        viewList.addEventHandler(MouseEvent.MOUSE_CLICKED, listEH);

        updateViews();

    }
    public void updateViews(){
        ResultSet rs;
        try{
            final ObservableList<ModelTransaction> items = FXCollections.observableArrayList();
            rs = new ModelTransaction().search("userID = " + App.getUser().userID);
            while(rs.next()) items.add(new ModelTransaction(rs.getInt("transactionID")));
            viewList.setItems(items);
        }catch(Exception e){System.out.println(e);}
    }
    public Parent getViews(){
        VBox views = new ViewHome().getViews();
        views.getChildren().add(pane);
        return views;
    }

    EventHandler<MouseEvent> listEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) { 
            selectedItem =  viewList.getSelectionModel().getSelectedItem();
            final ObservableList<ModelTransactionDetail> items = FXCollections.observableArrayList();
            for(ModelTransactionDetail detail : selectedItem.transactionDetails) {
                items.add(detail);
            }
            detailList.setItems(items);            
        }
    };
}
