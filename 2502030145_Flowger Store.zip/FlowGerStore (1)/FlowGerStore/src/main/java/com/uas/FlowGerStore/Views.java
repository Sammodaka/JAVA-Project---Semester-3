package com.uas.FlowGerStore;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class Views {
    public AlertType INFORMATION = AlertType.INFORMATION;
    public AlertType WARNING = AlertType.WARNING;
    public AlertType ERROR = AlertType.ERROR;

    public static Font headerFont = Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR,20);
    public static Font labelFont = Font.font("verdana", FontWeight.LIGHT, FontPosture.REGULAR,12);
    public static Font buttonFont = Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR,11);

    public void alert(String message, AlertType type){
        Alert alert = new Alert(type);
        alert.setHeaderText(message);
        alert.setTitle("FloWGer Store");
        alert.show();
    }
}
