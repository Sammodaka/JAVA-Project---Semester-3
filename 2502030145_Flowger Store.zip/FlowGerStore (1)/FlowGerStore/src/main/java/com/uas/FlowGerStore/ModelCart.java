package com.uas.FlowGerStore;

import java.sql.ResultSet;

public class ModelCart extends Model {
    public String tableName = "cart";

    public int userID;
    public ModelFlower flowerID;
    public int quantity;

    public ModelCart(){}
    public ModelCart(int uid, int fid){
        ResultSet rs;
        try{
            rs = this.search("userID = " + uid + " and flowerID = " + fid);
            if(rs.next()){
                userID = rs.getInt("userID");
                flowerID = new ModelFlower(rs.getInt("flowerID"));
                quantity = rs.getInt("quantity");
            }
        }catch(Exception e){System.out.println(e);}
    }
    public ModelCart(ResultSet rs){
        try{
            userID = rs.getInt("userID");
            flowerID = new ModelFlower(rs.getInt("flowerID"));
            quantity = rs.getInt("quantity");
        }catch(Exception e){System.out.println(e);}
    }
    
}
