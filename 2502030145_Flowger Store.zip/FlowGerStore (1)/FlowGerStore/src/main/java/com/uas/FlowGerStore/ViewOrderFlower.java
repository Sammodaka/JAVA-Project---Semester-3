package com.uas.FlowGerStore;

import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.ResultSet;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.util.Callback;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

public class ViewOrderFlower extends Views {
    private ModelFlower selectedItem = null;

    private TableView<ModelFlower> viewList = new TableView<ModelFlower>();
    private TableColumn<ModelFlower, Integer> flowerIDColumn = new TableColumn<ModelFlower, Integer>("Flower ID");
    private TableColumn<ModelFlower, String> flowerNameColumn = new TableColumn<ModelFlower, String>("Flower Name"); 
    private TableColumn<ModelFlower, String> flowerTypeColumn = new TableColumn<ModelFlower, String>("Flower Type");
    private TableColumn<ModelFlower, Integer> flowerPriceColumn = new TableColumn<ModelFlower, Integer>("Flower Price");
    private TableColumn<ModelFlower, Integer> flowerStockColumn = new TableColumn<ModelFlower, Integer>("Flower Stock");

    private TableView<ModelCart> cartList = new TableView<ModelCart>();
    private TableColumn<ModelCart, Integer> cartFlowerIDColumn = new TableColumn<ModelCart, Integer>("Flower ID");
    private TableColumn<ModelCart, Integer> cartQuantityColumn = new TableColumn<ModelCart, Integer>("Quantity");

    private Label idLabel = new Label("Flower ID");
    private Label nameLabel = new Label("Flower Name");
    private Label typeLabel = new Label("Flower Type");
    private Label quantityLabel = new Label("Quantity");

    private TextField idField = new TextField();
    private TextField nameField = new TextField();
    private TextField typeField = new TextField();
    private Spinner<Integer> quantityField =  new Spinner<Integer>(1,100,0,1);

    private Button addToCartButton = new Button("Add to Cart");
    private Button checkOutButton = new Button("Check Out");

    private GridPane formPane = new GridPane();
    private HBox hbox;
    private VBox pane;

    public ViewOrderFlower(){
        flowerIDColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelFlower, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerID)).asObject();
            }
        });
        flowerNameColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelFlower, String> p) {
                return new SimpleStringProperty(p.getValue().flowerName);
            }
        });
        flowerTypeColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<ModelFlower, String> p) {
                return new SimpleStringProperty(p.getValue().typeID.typeName);
            }
        });
        flowerPriceColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelFlower, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerPrice)).asObject();
            }
        });
        flowerStockColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelFlower, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelFlower, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().flowerStock)).asObject();
            }
        });
        viewList.getColumns().addAll(flowerIDColumn,flowerNameColumn,flowerTypeColumn,flowerPriceColumn,flowerStockColumn);

        cartFlowerIDColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelCart, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelCart, Integer> p) {
                var o = p.getValue();
                return new SimpleIntegerProperty(Integer.valueOf(o.flowerID != null ? o.flowerID.flowerID : 0)).asObject();
            }
        });
        cartQuantityColumn.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<ModelCart, Integer>, ObservableValue<Integer>>() {
            @Override
            public ObservableValue<Integer> call(TableColumn.CellDataFeatures<ModelCart, Integer> p) {
                return new SimpleIntegerProperty(Integer.valueOf(p.getValue().quantity)).asObject();
            }
        });
        cartList.getColumns().addAll(cartFlowerIDColumn,cartQuantityColumn);

        addToCartButton.setPrefWidth(300);
        checkOutButton.setPrefWidth(300);

        idField.setDisable(true);
        nameField.setDisable(true);
        typeField.setDisable(true);

        idField.setPromptText("Flower ID");
        nameField.setPromptText("Flower Name");
        typeField.setPromptText("Flower Type");

        formPane.add(idLabel,0,0);
        formPane.add(idField,1,0);
        formPane.add(nameLabel,0,1);
        formPane.add(nameField,1,1);
        formPane.add(typeLabel,0,2);
        formPane.add(typeField,1,2);
        formPane.add(quantityLabel,0,3);
        formPane.add(quantityField,1,3);
        formPane.add(addToCartButton,0,4,2,1);
        formPane.add(checkOutButton,0,5,2,1);
        formPane.setVgap(10);
        formPane.setHgap(10);

        hbox = new HBox(cartList,formPane);
        hbox.setSpacing(100);
        hbox.setAlignment(Pos.CENTER_LEFT);

        pane = new VBox(viewList,hbox);
        pane.setSpacing(10);
        pane.setPadding(new Insets(20, 20, 0, 20));
        pane.setAlignment(Pos.CENTER);

        pane.setStyle("-fx-background-color:rgba(20, 90, 200, 0.7)");

        App.setWidth(650.0);

        viewList.addEventHandler(MouseEvent.MOUSE_CLICKED, listEH);
        addToCartButton.addEventHandler(MouseEvent.MOUSE_CLICKED,createEH);
        checkOutButton.addEventHandler(MouseEvent.MOUSE_CLICKED,checkoutEH);

        updateViews();
    }

    public void updateViews(){
        ResultSet rs;
        try{
            final ObservableList<ModelFlower> items = FXCollections.observableArrayList();
            rs = new ModelFlower().search("");
            while(rs.next()) items.add(new ModelFlower(rs.getInt("flowerID")));
            viewList.setItems(items);

            final ObservableList<ModelCart> cartItems = FXCollections.observableArrayList();
            rs = new ModelCart().search("userID = " + App.getUser().userID);
            while(rs.next()) cartItems.add(new ModelCart(rs.getInt("userID"),rs.getInt("flowerID")));
            cartList.setItems(cartItems);

        }catch(Exception e){System.out.println(e);}
    }
    public void clearFormViews(){
        idField.setText("");
        nameField.setText("");
        typeField.setText("");
        quantityField.getValueFactory().setValue(0);
    }

    public Parent getViews(){
        VBox views = new ViewHome().getViews();
        views.getChildren().add(pane);
        return views;
    }

    EventHandler<MouseEvent> listEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) { 
            selectedItem =  viewList.getSelectionModel().getSelectedItem();
            idField.setText(String.valueOf(selectedItem.flowerID));
            nameField.setText(selectedItem.flowerName);
            typeField.setText(selectedItem.typeID.typeName);
        }
    };

    EventHandler<MouseEvent> createEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            boolean validate = validateFields();
            if (validate) {
                try{
                    String data ="("+ App.getUser().userID + "," + selectedItem.flowerID +","+quantityField.getValue()+")";
                    new ModelCart().create(data);
                    selectedItem = null;
                    alert("Added to cart!",INFORMATION);
                    updateViews();
                    clearFormViews();
                }catch(Exception err){
                    System.out.println(err);
                    alert("Something went wrong!",ERROR);
                }
            }
        }
    };

    EventHandler<MouseEvent> checkoutEH = new EventHandler<MouseEvent>() { 
        @Override 
        public void handle(MouseEvent e) {
            if (cartList.getItems().size() > 0) {
                try{
                    var modelTransaction = new ModelTransaction();
                    int tid = modelTransaction.getNewID();
                    modelTransaction.create("("+tid+","+App.getUser().userID+",DATE_FORMAT(NOW(),'%d-%m-%Y'))");
                    for(ModelCart cart :cartList.getItems()){
                        new ModelTransactionDetail().create("("+tid+","+cart.flowerID.flowerID+","+cart.quantity+")");
                        new ModelFlower().write("flowerStock = "+(cart.flowerID.flowerStock - cart.quantity), "flowerID = " + cart.flowerID.flowerID);
                    }
                    new ModelCart().unlink("userID = " + App.getUser().userID);
                    alert("Successully Checkout!",INFORMATION);
                    updateViews();
                    clearFormViews();
                }catch(Exception err){
                    System.out.println(err);
                    alert("Something went wrong!",ERROR);
                }
            }
        }
    };

    public boolean validateFields(){
        if(selectedItem == null){
            alert("Please select a flower!",ERROR);
            return false;
        }else if(quantityField.getValue() > selectedItem.flowerStock){
            alert("Quantity can't exceed the available stock",ERROR);
            return false;
        }
        return true;
    }


}
