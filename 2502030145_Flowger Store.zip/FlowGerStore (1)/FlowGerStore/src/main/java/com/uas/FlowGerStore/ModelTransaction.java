package com.uas.FlowGerStore;

import java.sql.ResultSet;
import java.util.Vector;

public class ModelTransaction extends Model{
    public String tableName = "transaction";

    public int transactionID;
    public ModelUser userID;
    public String transactionDate;
    public Vector<ModelTransactionDetail> transactionDetails = new Vector<ModelTransactionDetail>();

    public ModelTransaction() {}
    public ModelTransaction(int id){
        ResultSet res;
        try{
            res = this.search("transactionID = "+id);
            if(res.next()){

                transactionID = res.getInt("transactionID");
                userID = new ModelUser(res.getInt("userID"));
                transactionDate = res.getString("transactionDate");
                var transactionDetail = new ModelTransactionDetail();
                res = transactionDetail.search("transactionID = "+transactionID);
                int i = 0;
                while(res.next()){
                    transactionDetails.add(i,new ModelTransactionDetail(transactionID,new ModelFlower(res.getInt("flowerID")),res.getInt("quantity")));
                }
            }
        }catch(Exception e){System.out.println(e);}
    }

    public int getNewID() throws Exception{
        ResultSet rs = this.search("");
        int id = 0;
        while(rs.next()){
            int cid = rs.getInt("transactionID");
            id = cid > id?cid:id;
        }
        return id + 1;
    }

    public int getTotalPrice() {
        int total = 0;
        for(ModelTransactionDetail detail : transactionDetails){
            total = total + (detail.flowerID.flowerPrice * detail.quantity);
        }
        return total;
    }
}
