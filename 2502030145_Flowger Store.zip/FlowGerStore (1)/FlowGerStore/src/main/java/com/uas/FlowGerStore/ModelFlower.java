package com.uas.FlowGerStore;

import java.sql.ResultSet;

public class ModelFlower extends Model{
    public String tableName = "flower";

    public int flowerID;
    public ModelFlowerType typeID;
    public String flowerName;
    public int flowerPrice;
    public int flowerStock;

    public ModelFlower(){}
    public ModelFlower(int id){
        ResultSet res;
        try{
            res = this.search("flowerID = "+id);
            if(res.next()){
                flowerID = res.getInt("flowerID");
                typeID = new ModelFlowerType(res.getInt("typeID"));
                flowerName = res.getString("flowerName");
                flowerPrice = res.getInt("flowerPrice");
                flowerStock = res.getInt("flowerStock");
            }
        }catch(Exception e){System.out.println(e);}
    }

    public int getNewID() throws Exception{
        ResultSet rs = this.search("");
        int id = 0;
        while(rs.next()){
            int cid = rs.getInt("flowerID");
            id = cid > id?cid:id;
        }
        return id + 1;
    }
}
